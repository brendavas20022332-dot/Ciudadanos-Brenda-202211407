<?php echo $this->extend('layouts/main'); ?>
<?php echo $this->section('content'); ?>
<h1 class="mb-4">Gestión de Ciudadanos</h1>
<div class="list-group">
<a class="list-group-item list-group-item-action py-3" href="<?= base_url('ciudadanos') ?>">Ciudadanos</a>
<a class="list-group-item list-group-item-action py-3" href="<?= base_url('departamentos') ?>">Departamentos</a>
<a class="list-group-item list-group-item-action py-3" href="<?= base_url('municipios') ?>">Municipios</a>
<a class="list-group-item list-group-item-action py-3" href="<?= base_url('regiones') ?>">Regiones</a>
<a class="list-group-item list-group-item-action py-3" href="<?= base_url('niveles') ?>">Niveles Académicos</a>
</div>
<?php echo $this->endSection(); ?>
